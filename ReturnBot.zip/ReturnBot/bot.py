from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
)
from datetime import datetime
import bd  

TOKEN = "Токен Телеграм"
ADMIN_ID = Айди телеграм   

user_message_map = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Привет, напиши своё сообщение и мы постараемся ответить вам в ближайшее время! 🌜"
    )

async def user_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.message.from_user
    text = update.message.text
    user_id = user.id

    
    bd.add_user(user_id, user.full_name, user.username if user.username else "")

    
    await update.message.reply_text(
        "Отлично! Ваше сообщение отправлено. Мы отправим ответ в ближайшее время."
    )

    now = datetime.now().strftime("%d/%m/%Y в %H:%M")
    username = f"@{user.username}" if user.username else "(без username)"
    admin_text = (
        f"Новое сообщение от пользователя:\n"
        f"Имя: {user.full_name}\n"
        f"Тег: {username}\n"
        f"Время отправки: {now}\n\n"
        f"Сообщение:\n{text}"
    )

    sent_message = await context.bot.send_message(chat_id=ADMIN_ID, text=admin_text)

    user_message_map[sent_message.message_id] = user_id

async def admin_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.chat_id != ADMIN_ID:
        return

    if not update.message.reply_to_message:
        return

    replied_msg_id = update.message.reply_to_message.message_id

    if replied_msg_id not in user_message_map:
        await update.message.reply_text("Ошибка: не могу найти пользователя для ответа.")
        return

    user_id = user_message_map[replied_msg_id]
    answer_text = update.message.text

    await context.bot.send_message(
        chat_id=user_id,
        text=f"Сообщение от админа:\n{answer_text}"
    )

    await update.message.reply_text("Ответ отправлен! ✅")

if __name__ == "__main__":
    app = ApplicationBuilder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND) & (~filters.Chat(ADMIN_ID)), user_message))
    app.add_handler(MessageHandler(filters.TEXT & filters.Chat(ADMIN_ID), admin_reply))

    print("Бот запущен...")
    app.run_polling()

#By @Alekss404